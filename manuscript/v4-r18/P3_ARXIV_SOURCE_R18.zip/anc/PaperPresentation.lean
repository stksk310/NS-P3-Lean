import NSP3.L12Final
import NSP3.NumericalClassCoverage

namespace NSP3.Paper

noncomputable def presentationCardinality (S : Set ℕ) : ℕ :=
  sInf {n : ℕ | ∃ R : Finset (AtomCoefficients S × AtomCoefficients S),
    IsAtomPresentation S R ∧ R.card = n}

def presentationCardinalities (m : ℕ) : Set ℕ :=
  {n | ∃ S : AddSubmonoid ℕ, ((S : Set ℕ)ᶜ).Finite ∧
    semigroupEmbeddingDimension (S : Set ℕ) = 4 ∧
    IsSemigroupMultiplicity (S : Set ℕ) m ∧
    presentationCardinality (S : Set ℕ) = n}

theorem max_presentation_cardinality (m : ℕ) (hm : 4 ≤ m) :
    IsGreatest (presentationCardinalities m)
      ⌊(2 : ℝ) + 2 * Real.sqrt (m : ℝ)⌋₊ :=
  L12_P3_isGreatest m hm

theorem minimal_presentation_cardinality
    (S : AddSubmonoid ℕ) (m : ℕ)
    (hcof : ((S : Set ℕ)ᶜ).Finite)
    (hedim : semigroupEmbeddingDimension (S : Set ℕ) = 4)
    (hm : IsSemigroupMultiplicity (S : Set ℕ) m)
    (R : Finset (AtomCoefficients (S : Set ℕ) × AtomCoefficients (S : Set ℕ)))
    (hR : IsAtomPresentation (S : Set ℕ) R)
    (hmin : ∀ T, T ⊂ R → ¬ IsAtomPresentation (S : Set ℕ) T) :
    R.card = presentationCardinality (S : Set ℕ) :=
  numerical_semigroup_minimal_presentation_card S m hcof hedim hm R hR hmin

end NSP3.Paper

#print axioms NSP3.Paper.max_presentation_cardinality
#print axioms NSP3.Paper.minimal_presentation_cardinality
