import PaperTheorems
import P3TorSpike.FinalChecks

#print axioms NSP3.Paper.max_presentation_card_eq
#print axioms NSP3.Paper.attainable_presentation_cardinalities
#print axioms NSP3.Paper.macaulay_equality_iff
