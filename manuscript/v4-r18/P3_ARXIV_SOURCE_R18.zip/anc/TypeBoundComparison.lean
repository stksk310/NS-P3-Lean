import NSP3.MacaulayC3
import NSP3.V03.TypeExtrema

set_option autoImplicit false

namespace NSP3.Paper

/-- Lower the top of each binomial by one, keeping its bottom index. -/
def loweredBinomialValue : ℕ → List ℕ → ℕ
  | _, [] => 0
  | r, a :: ds => (a - 1).choose r + loweredBinomialValue (r - 1) ds

/-- The Elias–Geramita–Valla type bound in embedding dimension four,
using the degree and the remainder from the canonical binomial interval. -/
def macaulayTypeBound (m : ℕ) : ℕ :=
  (c3Degree m + 1).choose 2 +
    loweredBinomialValue (c3Degree m) (macaulayDigits (c3Degree m) (c3Remainder m))

theorem macaulayTypeBound_formula (m r : ℕ) (hm : 1 ≤ m)
    (hl : (r + 2).choose 3 ≤ m) (hu : m < (r + 3).choose 3) :
    macaulayTypeBound m = (r + 1).choose 2 +
      loweredBinomialValue r (macaulayDigits r (m - (r + 2).choose 3)) := by
  simp only [macaulayTypeBound, c3Remainder, c3Degree_unique m r hm hl hu]

private theorem binomial_square_comparison (t : ℕ) :
    4 * (t + 9).choose 3 < ((t + 7).choose 2 - 1) ^ 2 := by
  let K := (t + 7).choose 2
  let U := (t + 9).choose 3
  change 4 * U < (K - 1) ^ 2
  have hK : 2 * K = (t + 7) * (t + 6) := c3_choose_two_poly (t + 5)
  have hU : 6 * U = (t + 9) * (t + 8) * (t + 7) := c3_choose_three_poly (t + 6)
  have hKpos : 1 ≤ K := Nat.choose_pos (by omega)
  have hsub := Nat.sub_add_cancel hKpos
  have htwice : 2 * (K - 1) = (t + 5) * (t + 8) := by
    nlinarith only [hK, hsub]
  have hgap : 12 * (K - 1)^2 =
      48 * U + (3*t^4 + 70*t^3 + 555*t^2 + 1592*t + 768) := by
    calc
      12 * (K - 1)^2 = 3 * (2 * (K - 1))^2 := by ring
      _ = 8 * ((t + 9) * (t + 8) * (t + 7)) +
          (3*t^4 + 70*t^3 + 555*t^2 + 1592*t + 768) := by rw [htwice]; ring
      _ = _ := by rw [← hU]; ring
  omega

/-- The square-root bound improves the cited type bound for every multiplicity
at least 32. Only the interval 32 through 55 is evaluated case by case. -/
theorem sqrt_bound_lt_macaulay_type_bound (m : ℕ) (hm : 32 ≤ m) :
    1 + Nat.sqrt (4 * m) < macaulayTypeBound m := by
  by_cases hsmall : m < 56
  · interval_cases m <;> norm_num <;> decide
  have hinterval := (c3Degree_interval m (by omega)).2
  have hr : 6 ≤ c3Degree m := by
    by_contra h
    have hmono := Nat.choose_le_choose 3 (show c3Degree m + 3 ≤ 8 by omega)
    rw [show (8 : ℕ).choose 3 = 56 by decide] at hmono
    omega
  obtain ⟨t, ht⟩ := Nat.exists_eq_add_of_le hr
  have hK : (t + 7).choose 2 ≤ macaulayTypeBound m := by
    unfold macaulayTypeBound
    rw [show c3Degree m + 1 = t + 7 by omega]
    exact Nat.le_add_right _ _
  have hm' : m < (t + 9).choose 3 := by
    simpa only [show c3Degree m + 3 = t + 9 by omega] using hinterval
  have hsq : 4 * m < ((t + 7).choose 2 - 1)^2 :=
    lt_trans (by omega) (binomial_square_comparison t)
  have hsqrt := Nat.sqrt_lt'.mpr hsq
  omega

/-- The four-generator case of Moscariello–Sammartano's type conjecture,
using the attained maximum over cofinite numerical semigroups. -/
theorem maximum_type_lt_macaulay_type_bound (m : ℕ) (hm : 32 ≤ m) :
    V03.maximumType m < macaulayTypeBound m := by
  have h := (V03.maximumType_window m (by omega)).2
  have hs : V03.T m - 1 = 1 + Nat.sqrt (4 * m) := by unfold V03.T; omega
  rw [hs] at h
  exact lt_of_le_of_lt h (sqrt_bound_lt_macaulay_type_bound m hm)

theorem type_bound_comparison_at_31 :
    1 + Nat.sqrt (4 * 31) = macaulayTypeBound 31 := by
  norm_num
  decide

end NSP3.Paper

#print axioms NSP3.Paper.macaulayTypeBound_formula
#print axioms NSP3.Paper.sqrt_bound_lt_macaulay_type_bound
#print axioms NSP3.Paper.maximum_type_lt_macaulay_type_bound
#print axioms NSP3.Paper.type_bound_comparison_at_31
