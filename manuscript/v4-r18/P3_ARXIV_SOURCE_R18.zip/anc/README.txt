Lean supplement for the four-generated numerical semigroups preprint (R18)

TypeBoundComparison.lean gives the Lean proof of Corollary 4.7.
PaperTheorems.lean provides the other manuscript interfaces.
PaperPresentation.lean contains the definitions used in the appendix.
PaperChecks.lean provides additional checks.

The base project and pins are at https://doi.org/10.5281/zenodo.24346459.
Use the locked dependencies and Lean version in that archived project.
Copy the four Lean files into its root directory. From that directory:

    lake exe cache get
    lake build NSP3 P3Betti
    lake env lean -DautoImplicit=false -DrelaxedAutoImplicit=false -o .lake/build/lib/lean/PaperTheorems.olean PaperTheorems.lean
    lake env lean -DautoImplicit=false -DrelaxedAutoImplicit=false PaperChecks.lean
    lake env lean -DautoImplicit=false -DrelaxedAutoImplicit=false PaperPresentation.lean
    lake env lean -DautoImplicit=false -DrelaxedAutoImplicit=false TypeBoundComparison.lean

lean-verification.zip contains the source-build records, the separate
appendix and type comparison logs, finite-verification scripts and receipts,
and the R12 change record.
The manuscript is licensed under CC BY 4.0. See LICENSE.txt for the
original Lean supplement and verification scripts (Apache 2.0).

finite-verification.zip contains the current finite-verification scripts.
Extract it and run python verify_revision.py --source /path/to/P3_EDITORIAL_R18.tex.
