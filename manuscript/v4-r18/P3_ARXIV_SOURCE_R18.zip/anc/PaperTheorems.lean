import NSP3.L12Final
import NSP3.P4Final
import NSP3.V03.SpectrumSmall
import P3Betti

namespace NSP3.Paper

theorem max_presentation_card_eq (m : ℕ) (hm : 4 ≤ m) :
    IsGreatest (sharpRhoValues m)
      ⌊(2 : ℝ) + 2 * Real.sqrt (m : ℝ)⌋₊ :=
  L12_P3_isGreatest m hm

alias attainable_presentation_cardinalities := V03.complete_spectrum
alias macaulay_equality_iff := P4_e3

end NSP3.Paper
