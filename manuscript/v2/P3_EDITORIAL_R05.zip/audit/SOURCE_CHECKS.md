# 原典の確認

- Herzog (1970) の出版社要旨と書誌を確認した。要旨が明記するのは対称性と完全交叉性の同値である。三生成で関係式数が高々3という主張は、Herzog 本人と Stamate の後続論文の Introduction（arXiv v3 の PDF 2ページ目）で確認した。同論文の文献 [10] が Herzog (1970) を指す。原稿では両方を引用し、1970年の本文に未確認の定理番号を付けていない。
  [Herzog (1970)](https://doi.org/10.1007/BF01273309) · [Herzog–Stamate の著者版](https://arxiv.org/pdf/1308.4644v3) · [出版社版](https://doi.org/10.1016/j.jalgebra.2014.07.008)
- Apéry (1946) は Herzog (1970) の文献 [1] と MathSciNet MR0017942 で書誌を照合した。引用は呼称の歴史的参照で、1946年本文の定理を援用していない。
  [MathSciNet](https://mathscinet.ams.org/mathscinet/2006/mathscinet/mrcit/individual.html?mrauthid=26575)
- Rosales–García-Sánchez (2009) は出版社の第2章「Notable elements」（pp. 5–18）の要旨で Apéry 集合を扱うことを確認した。定義への一般的な参照として追加した。
  [第2章](https://doi.org/10.1007/978-1-4419-0160-6_2)
- Chomicz, *On numerical semigroups with embedding dimension four*, arXiv:2604.25653v3 を再確認した。§2 の Theorem 2.2 は Apéry 集合の幾何的構成を扱う。§3 の Theorem 3.2 は Betti 要素から最小表示を組み立てる既知の記述で、Theorem 3.4 は仮定 (29) の下で Betti 要素を絞る。§§4–5 の Corollaries 4.4, 5.4 は、それぞれ連続平方数族と連続三角数族の最小表示の濃度を与える。§6 は §3 の手順を全四生成数値半群に広げる問題を述べている。これらと本文の上界への言及を確認した範囲で、固定多重度の全四生成数値半群に対する η の上界は見当たらなかった。別論文にある type による \(\eta\) の評価は引き続き別の結果として引用する。
  [幾何の論文 v3](https://arxiv.org/pdf/2604.25653v3) · [type の論文 v1](https://arxiv.org/abs/2609.04000v1)
