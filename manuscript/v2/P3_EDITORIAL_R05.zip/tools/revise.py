"""Apply the R05 editorial corrections to the frozen R04 manuscript."""
import argparse
import difflib
import hashlib
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--base", type=Path, default=ROOT/"baseline/P3_EDITORIAL_R04.tex")
args = parser.parse_args()
data = args.base.read_bytes()
if hashlib.sha256(data).hexdigest() != "037369d9577a6a561797e9b039666489a926a5fd5467d2361dedc55e70b69dc0":
    raise ValueError("Unexpected R04 baseline")
old = data.decode("utf-8")

old_counter = r"\newtheorem{remark}{Remark}[section]"
new_counter = r"\newtheorem{remark}[theorem]{Remark}"
if old.count(old_counter) != 1:
    raise ValueError("Missing unique Remark counter")
new = old.replace(old_counter, new_counter, 1)

start = new.index(r"\section*{Appendix. Lean definitions")
end = new.index(r"\section*{Declarations}", start)
appendix = new[start:end]
before = r"""Here \texttt{sInf} takes the least cardinality among the finite
presentations of $S$. Lean proves that every inclusion-minimal
presentation of a four-generated numerical semigroup has this
cardinality, giving $\eta(S)$. The second definition collects these
values over all four-generated numerical semigroups of multiplicity $m$."""
after = r"""Proposition~\ref{prop:border} gives a finite presentation, so the set
of cardinalities in \texttt{sInf} is nonempty. Its least element is
$\eta(S)$, since Lean proves that every inclusion-minimal presentation
of a four-generated numerical semigroup has this cardinality.
The embedding dimension counts the minimal generators, and the
multiplicity predicate says that $m$ is the least positive element.
The second definition collects the values of $\eta(S)$ at embedding
dimension four and multiplicity $m$."""
if appendix.count(before) != 1:
    raise ValueError("Missing unique appendix paragraph")
appendix = appendix.replace(before, after, 1)
# The Lean excerpt uses TeX math glyphs inside typewriter text.
appendix = re.sub(r" : (?=\\\(\\mathbb [NR]\\\))", r" :\\kern.32em", appendix)
new = new[:start] + appendix + new[end:]

with (ROOT/"manuscript/P3_EDITORIAL_R05.tex").open("w",encoding="utf-8",newline="\n") as f:
    f.write(new)
with (ROOT/"audit/R04_TO_R05.patch").open("w",encoding="utf-8",newline="\n") as f:
    f.writelines(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
                                     fromfile="R04.tex",tofile="R05.tex"))
