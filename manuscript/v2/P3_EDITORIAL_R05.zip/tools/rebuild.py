"""Compile project sources into a fresh project-output directory.

External dependency oleans are reused.  No previous NSP3 olean path is present.
Each compiler invocation, source hash, output hash and elapsed time is logged.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
LEAN = Path(r"C:\Users\stksk\.elan\toolchains\leanprover--lean4---v4.34.0-rc1\bin\lean.exe")
PACKAGES = Path(r"C:\LeanProjects\Problem23Lean\.lake\packages")
DEPS = ["mathlib", "plausible", "LeanSearchClient", "importGraph", "proofwidgets",
        "aesop", "Qq", "batteries", "Cli"]

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path: Path, value: object) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="source_clean_build_01")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--packages", type=Path, default=PACKAGES)
    parser.add_argument("--lean", type=Path, default=LEAN)
    parser.add_argument("--baseline", type=Path, default=ROOT.parent / "revision_p3_r02_20261119/baseline")
    args = parser.parse_args()
    output = (ROOT / "work" / args.out).resolve()
    if not output.is_relative_to(ROOT / "work"):
        raise ValueError("Output must stay within this workspace's work directory")
    output.mkdir(parents=True, exist_ok=False)
    lib = output / "lib" / "lean"
    logdir = output / "logs"
    lib.mkdir(parents=True)
    logdir.mkdir()
    project = output / "project"
    project.mkdir()
    frozen = json.loads((args.baseline / "CURRENT_SOURCES.json").read_text())
    pins = json.loads((args.baseline / "DEPENDENCY_PINS.json").read_text())
    with zipfile.ZipFile(args.baseline / "NS_P3_TOR_BETTI_COMPLETION_20261116.zip") as archive:
        for name, digest in (frozen["lean_sources"] | frozen["config"]).items():
            data = archive.read("project/" + name)
            if hashlib.sha256(data).hexdigest() != digest:
                raise ValueError(f"Frozen hash mismatch: {name}")
            target = project / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    for name in ("PaperTheorems.lean", "PaperChecks.lean"):
        shutil.copy2(ROOT / "lean" / name, project / name)
    for dep in DEPS:
        head = (args.packages / dep / ".git/HEAD").read_text().strip()
        if head.startswith("ref: "):
            head = (args.packages / dep / ".git" / head[5:]).read_text().strip()
        if head != pins[dep]:
            raise ValueError(f"Dependency checkout mismatch: {dep} {head}")
    sources = {}
    for source in sorted(project.rglob("*.lean")):
        name = ".".join(source.relative_to(project).with_suffix("").parts)
        sources[name] = source
    graph = {}
    for name, source in sources.items():
        imports = re.findall(r"^[ \t]*(?:(?:public|private|meta)[ \t]+)*import[ \t]+([^\r\n]+)", source.read_text(encoding="utf-8-sig"), re.M)
        imports = [part for line in imports for part in line.split("--")[0].split()]
        graph[name] = set(imports) & sources.keys()
        missing = {part for part in imports if part.startswith(("NSP3.", "P3TorSpike."))} - sources.keys()
        if missing:
            raise ValueError(f"{name}: absent source modules {sorted(missing)}")
    env = os.environ.copy()
    closure = set()
    def visit(name):
        if name not in closure:
            closure.add(name)
            for dependency in graph[name]:
                visit(dependency)
    visit("PaperChecks")
    sources = {n:p for n,p in sources.items() if n in closure}
    scratch = output / "tmp"
    scratch.mkdir()
    env["TEMP"] = env["TMP"] = str(scratch)
    env["LEAN_PATH"] = os.pathsep.join([str(lib)] + [str(args.packages / dep / ".lake/build/lib/lean") for dep in DEPS])
    version = subprocess.run([str(args.lean), "--version"], capture_output=True, text=True, check=True).stdout.strip()
    if "4.34.0-rc1" not in version:
        raise ValueError(f"Wrong toolchain: {version}")
    metadata = {"classification": "fresh-project-outputs; cached external dependency oleans; same host",
                "version": version, "lean_path": env["LEAN_PATH"],
                "module_count": len(sources), "dependency_revisions": pins,
                "source_hashes": {name: sha(source) for name, source in sources.items()}}
    write_json(output / "metadata.json", metadata)
    print(json.dumps({"event": "start", "modules": len(sources), "version": version}), flush=True)
    completed = set()
    running = {}
    records = []
    started = time.monotonic()

    def compile_one(name: str) -> dict:
        source = sources[name]
        target = lib / source.relative_to(project).with_suffix(".olean")
        target.parent.mkdir(parents=True, exist_ok=True)
        before = sha(source)
        begin = time.monotonic()
        command = [str(args.lean), "-j", "1", "-o", str(target), str(source)]
        result = subprocess.run(command, cwd=project, env=env, capture_output=True, timeout=600)
        log = logdir / (name + ".log")
        log.write_bytes(result.stdout + result.stderr)
        after = sha(source)
        return {"module": name, "source_sha256": before, "source_unchanged": before == after,
                "exit_code": result.returncode, "elapsed_seconds": round(time.monotonic()-begin, 3),
                "olean_sha256": sha(target) if target.exists() else None,
                "log": str(log.relative_to(output)), "command": command}

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        pending = set(sources)
        failed = False
        while pending or running:
            ready = sorted(name for name in pending if graph[name] <= completed)
            while ready and len(running) < args.workers and not failed:
                name = ready.pop(0)
                pending.remove(name)
                running[executor.submit(compile_one, name)] = name
            if not running:
                if pending and not failed:
                    raise ValueError(f"Cyclic/blocked import graph: {sorted(pending)[:10]}")
                break
            done, _ = concurrent.futures.wait(running, return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                name = running.pop(future)
                record = future.result()
                records.append(record)
                ok = record["exit_code"] == 0 and record["source_unchanged"] and record["olean_sha256"]
                if ok:
                    completed.add(name)
                else:
                    failed = True
                print(json.dumps({"event": "compiled" if ok else "FAILED", "module": name,
                                  "done": len(completed), "total": len(sources),
                                  "seconds": record["elapsed_seconds"]}), flush=True)
                write_json(output / "progress.json", {"completed": len(completed), "total": len(sources),
                                                      "failed": failed, "records": records})
        passed = not failed and len(completed) == len(sources)
        report = {"passed": passed, "completed": len(completed), "total": len(sources),
                  "elapsed_seconds": round(time.monotonic()-started, 3), "records": records}
        write_json(output / "receipt.json", report)
        print(json.dumps({"event": "finish", **{k:v for k,v in report.items() if k != "records"}}), flush=True)
        return 0 if passed else 1

if __name__ == "__main__":
    raise SystemExit(main())
