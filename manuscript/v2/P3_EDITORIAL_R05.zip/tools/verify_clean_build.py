"""Verify the R03 Lean evidence, optionally rehashing local compiler outputs."""
import argparse
import hashlib
import json
from pathlib import Path, PureWindowsPath
import re
import zipfile


def need(condition, description):
    if not condition:
        raise ValueError(description)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def verify(root, baseline, evidence, build=None):
    metadata = read_json(evidence / "metadata.json")
    receipt = read_json(evidence / "receipt.json")
    progress = read_json(evidence / "progress.json")
    pins = read_json(baseline / "DEPENDENCY_PINS.json")
    frozen = read_json(baseline / "CURRENT_SOURCES.json")
    archive = baseline / "NS_P3_TOR_BETTI_COMPLETION_20261116.zip"
    need(sha(archive.read_bytes()) ==
         "ce5ce71cb201b7f122223ea49d2a23120133dd5faefe2068cf667d6e4a34cfb8", "Frozen Lean archive")
    sources = {}
    with zipfile.ZipFile(archive) as z:
        for name, expected in (frozen["lean_sources"] | frozen["config"]).items():
            data = z.read("project/" + name)
            need(sha(data) == expected, f"Frozen archive hash: {name}")
            if build:
                need(sha((build/"project"/name).read_bytes()) == expected, f"Build input hash: {name}")
            if name.endswith(".lean"):
                sources[name] = data
        compiler_pin = z.read("project/lean-toolchain").decode().strip()
        lake = json.loads(z.read("project/lake-manifest.json"))
    for name in ("PaperTheorems.lean", "PaperChecks.lean"):
        sources[name] = (root/"lean"/name).read_bytes()
        if build:
            need((build/"project"/name).read_bytes() == sources[name], f"R03 build input: {name}")
    need(compiler_pin == "leanprover/lean4:v4.34.0-rc1", "Lean toolchain pin")
    need(re.search(r"^Lean \(version 4\.34\.0-rc1, .*commit 3447a668783dbce1a8fdb97101dd067687b2b418, Release\)$",
                   metadata["version"]), "Compiler version and commit")
    need(len(pins) == 9 and metadata["dependency_revisions"] == pins
         == {p["name"]: p["rev"] for p in lake["packages"]}, "Dependency pins")
    lean_path = [PureWindowsPath(p) for p in metadata["lean_path"].split(";")]
    need(len(lean_path) == len(pins)+1 and lean_path[0].parts[-3:] ==
         ("source_clean_build_01", "lib", "lean"), "Fresh project output path")
    need({p.parts[-5] for p in lean_path[1:]} == set(pins) and
         all(p.parts[-4:] == (".lake", "build", "lib", "lean") for p in lean_path[1:]),
         "LEAN_PATH contains only the new project output and pinned dependency artifacts")
    if build:
        need(Path(lean_path[0]) == (build/"lib/lean").resolve(), "Local output directory")
        for p in lean_path[1:]:
            git = Path(p).parents[3] / ".git"
            head = (git/"HEAD").read_text().strip()
            if head.startswith("ref: "):
                head = (git/head[5:]).read_text().strip()
            need(head == pins[p.parts[-5]], f"Current dependency HEAD: {p.parts[-5]}")

    module_paths = {".".join(Path(name).with_suffix("").parts): name for name in sources}
    graph = {}
    for module, name in module_paths.items():
        lines = re.findall(r"^[ \t]*(?:(?:public|private|meta)[ \t]+)*import[ \t]+([^\r\n]+)",
                           sources[name].decode("utf-8-sig"), re.M)
        graph[module] = {token for line in lines for token in line.split("--")[0].split()} & module_paths.keys()
    closure = set()
    pending = ["PaperChecks"]
    while pending:
        module = pending.pop()
        if module not in closure:
            closure.add(module)
            pending.extend(graph[module])
    count = len(closure)
    need(count == metadata["module_count"] == receipt["completed"] == receipt["total"]
         == progress["completed"] == progress["total"] == 269, "Exact PaperChecks project closure")
    need(receipt["passed"] is True and progress["failed"] is False and receipt["elapsed_seconds"] > 0,
         "Terminal build PASS")
    records = receipt["records"]
    need(len(records) == count and records == progress["records"], "Final receipt/progress agreement")
    need(metadata["source_hashes"] == {m: sha(sources[module_paths[m]]) for m in closure},
         "Build metadata source hashes")
    lines = (evidence/"REBUILD.stdout.jsonl").read_text(encoding="utf-8-sig").splitlines()
    events = [json.loads(line) for line in lines]
    need(len(events) == count+2 and events[0] ==
         {"event":"start", "modules":count, "version":metadata["version"]}, "Controller start and event count")
    need(events[-1] == {"event":"finish", **{k:v for k,v in receipt.items() if k != "records"}},
         "Controller terminal event")

    completed = set()
    log_names = set()
    outputs = set()
    warning_count = 0
    for index, record in enumerate(records, 1):
        module = record["module"]
        need(module in closure and module not in completed and graph[module] <= completed,
             f"Unique module and dependency order: {module}")
        need(record["exit_code"] == 0 and record["source_unchanged"] is True
             and record["source_sha256"] == metadata["source_hashes"][module], f"Compiler input and exit: {module}")
        need(events[index] == {"event":"compiled","module":module,"done":index,
                              "total":count,"seconds":record["elapsed_seconds"]}, f"Controller event: {module}")
        name = module_paths[module]
        target = Path(name).with_suffix(".olean")
        log_name = f"{module}.log"
        need(PureWindowsPath(record["log"]).parts == ("logs",log_name), f"Log path: {module}")
        log = (evidence/"logs"/log_name).read_text(encoding="utf-8")
        need(not re.search(r"(?:\berror:|\bsorryAx\b|uses ['\x60]sorry['\x60])", log, re.I),
             f"Compiler diagnostic: {module}")
        warning_count += log.count("warning:")
        need(re.fullmatch("[0-9a-f]{64}", record["olean_sha256"]), f"Recorded output hash: {module}")
        command = record["command"]
        need(len(command) == 6 and command[1:4] == ["-j","1","-o"] and
             PureWindowsPath(command[0]).parts[-3:] == ("leanprover--lean4---v4.34.0-rc1","bin","lean.exe")
             and PureWindowsPath(command[4]) == lean_path[0]/PureWindowsPath(target)
             and PureWindowsPath(command[5]) == lean_path[0].parents[1]/"project"/PureWindowsPath(name),
             f"Compiler command: {module}")
        if build:
            need(sha((build/"lib/lean"/target).read_bytes()) == record["olean_sha256"], f"Output hash: {module}")
        log_names.add(log_name)
        outputs.add(target)
        completed.add(module)
    need(completed == closure and records[-1]["module"] == "PaperChecks", "Final project module")
    need({p.name for p in (evidence/"logs").glob("*.log")} == log_names, "Module log inventory")
    if build:
        lib = build/"lib/lean"
        need({p.relative_to(lib) for p in lib.rglob("*.olean")} == outputs, "Local olean inventory")

    axiom_reports = {}
    for module in ("P3TorSpike.FinalChecks", "PaperChecks"):
        expected = re.findall(r"^#print axioms ([^\s]+)", sources[module_paths[module]].decode(), re.M)
        actual = re.findall(r"^'([^']+)' depends on axioms: \[([^\]]+)\]$",
                            (evidence/"logs"/f"{module}.log").read_text(encoding="utf-8"), re.M)
        need([name for name,_ in actual] == expected and len(expected) == (3 if module == "PaperChecks" else 17),
             f"Axiom closure inventory: {module}")
        for name, axioms in actual:
            allowed = {"propext", "Classical.choice", "Quot.sound"}
            need(set(axioms.split(", ")) == allowed, f"Standard axioms: {name}")
            axiom_reports[name] = axioms.split(", ")
    return {"status":"PASS", "modules":count, "elapsed_seconds":receipt["elapsed_seconds"],
            "toolchain":compiler_pin, "compiler":metadata["version"], "dependency_revisions":pins,
            "frozen_lean_inputs":len(frozen["lean_sources"]), "frozen_config_files":len(frozen["config"]),
            "compiler_warnings":warning_count, "axiom_closures":axiom_reports,
            "local_project_inputs_and_outputs_rehashed":bool(build),
            "scope":"Same-host project source rebuild for PaperChecks with pinned external dependency artifacts."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--evidence", type=Path)
    parser.add_argument("--build", type=Path, help="Also rehash local project inputs and compiled oleans")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    print(json.dumps(verify(root, args.baseline or root/"baseline",
                            args.evidence or root/"audit/LEAN_CLEAN_BUILD", args.build), indent=2))


if __name__ == "__main__":
    main()
