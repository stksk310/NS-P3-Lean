# P3 改稿 R05

26ページのPDFは `output/pdf/P3_EDITORIAL_R05.pdf`、TeX原稿は `manuscript/P3_EDITORIAL_R05.tex` にあります。

第4章の定理類は Lemma 4.1、Proposition 4.2、Remarks 4.3–4.4、Corollaries 4.5–4.6 の通し番号です。付録には、埋め込み次元と多重度の意味、および有限表示の存在を保証する Proposition 2.1 への参照を補いました。R04からの差分は `audit/R04_TO_R05.patch` にあります。

Leanソースと固定ピンはR04のものです。269件の再ビルド記録は `audit/LEAN_CLEAN_BUILD/`、付録モジュールの検証結果は `audit/R04_VERIFICATION.json` にあります。R05ではTeXをビルドし、参照番号、PDFの表示、有限計算を確認しました。

~~~sh
tectonic manuscript/P3_EDITORIAL_R05.tex
python -B tools/verify_clean_build.py
python -B verification/verify_revision.py --source manuscript/P3_EDITORIAL_R05.tex
~~~

TeXは `python -B tools/revise.py` で同梱のR04原稿から再生成できます。配布物のハッシュは `SHA256SUMS.json` にあります。
